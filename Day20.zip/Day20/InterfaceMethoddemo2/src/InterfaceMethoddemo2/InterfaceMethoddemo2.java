package InterfaceMethoddemo2;

interface Test1{
	
	public static void run1 () {
		System.out.println("Interface Test1 and run1 static method");					//Static method so only implement interface
	}
}

public class InterfaceMethoddemo2 {

	public static void main(String[] args) {
		
		Test1.run1();
	}

}
