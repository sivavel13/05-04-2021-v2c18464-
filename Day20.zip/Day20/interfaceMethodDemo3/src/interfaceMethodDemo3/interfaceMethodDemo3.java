package interfaceMethodDemo3;

interface Test1{
	
	default void run1(){
		System.out.println("test1 default run1 method");
	}
}
interface Test2{
	default void run2() {
		System.out.println("test2 default run2 method");
	}
}
interface Test3{
	abstract void run3();	
}
interface Test4{
	public void run4();
}
public class interfaceMethodDemo3 implements Test1, Test2, Test3,Test4{
	
	public static void main(String[] args) {
		interfaceMethodDemo3 inter3 = new interfaceMethodDemo3();
		inter3.run1();
		inter3.run2();
		inter3.run3();
		inter3.run4();
	}
	@Override
	public void run4() {
		System.out.println("run4 method"); 
		
	}
	@Override
	public void run3() {
		System.out.println("run3 method"); 
		
	}

}
