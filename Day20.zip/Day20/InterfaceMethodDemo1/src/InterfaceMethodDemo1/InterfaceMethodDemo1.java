package InterfaceMethodDemo1;

interface Test1{
	
	default void run2() {
		System.out.println("run2 Default method");
	}
	
	void run1();
}
class Show1 implements Test1 {	
	
	public void run1() {
		System.out.println("run1 method");
	}
}
public class InterfaceMethodDemo1  {
	
	public static void main(String[] args) {	

		Show1 obj1 = new Show1();
		obj1.run1();
		obj1.run2();
		
	}	
}